package com.aspkumar.schoolhub;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 1001;
    private boolean desktopMode = false;
    private String mobileUserAgent;

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable buttonBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(9));
        return bg;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setMinWidth(dp(56));
        b.setBackground(buttonBg(Color.rgb(23, 105, 170)));
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(243, 246, 250));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(6), dp(8), dp(6));
        toolbar.setBackgroundColor(Color.WHITE);

        Button backButton = makeButton("← Back");
        Button homeButton = makeButton("⌂ Home");
        Button desktopButton = makeButton("Desktop: OFF");
        TextView title = new TextView(this);
        title.setText("ASP KUMAR");
        title.setTextColor(Color.rgb(16, 43, 70));
        title.setTextSize(13);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);

        toolbar.addView(backButton, new LinearLayout.LayoutParams(0, dp(42), 1.05f));
        toolbar.addView(homeButton, new LinearLayout.LayoutParams(0, dp(42), 1.05f));
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
        toolbar.addView(desktopButton, new LinearLayout.LayoutParams(0, dp(42), 1.25f));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 246, 250));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        mobileUserAgent = settings.getUserAgentString();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep website navigation inside this app so the native Back and Home
                // controls remain available.
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_PICKER);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        backButton.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
            else webView.evaluateJavascript(
                "if(document.getElementById('workspace') && document.getElementById('workspace').style.display!=='none'){document.getElementById('backBtn').click();}else if(document.getElementById('helpPanel')){document.getElementById('helpPanel').style.display='none';}",
                null);
        });

        homeButton.setOnClickListener(v -> {
            webView.loadUrl("file:///android_asset/index.html");
        });

        desktopButton.setOnClickListener(v -> {
            desktopMode = !desktopMode;
            WebSettings ws = webView.getSettings();
            if (desktopMode) {
                ws.setUseWideViewPort(true);
                ws.setLoadWithOverviewMode(true);
                ws.setUserAgentString(mobileUserAgent.replace("Android", "X11; Linux x86_64")
                    .replaceAll("; wv", ""));
                desktopButton.setText("Desktop: ON");
            } else {
                ws.setUserAgentString(mobileUserAgent);
                ws.setUseWideViewPort(false);
                ws.setLoadWithOverviewMode(false);
                desktopButton.setText("Desktop: OFF");
            }
            webView.reload();
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager != null) {
                    android.print.PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("ASP_KUMAR_School_Hub");
                    manager.print("ASP KUMAR School Hub", adapter,
                        new PrintAttributes.Builder().build());
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (webView != null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
