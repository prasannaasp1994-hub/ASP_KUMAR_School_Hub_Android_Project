ASP KUMAR SCHOOL HUB - ANDROID PROJECT

This is an Android Studio project containing the combined MDM Manager and AP Education/Government Portals web app.

BUILD APK
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Open Android Studio and choose Open.
3. Select this extracted folder: ASP_KUMAR_School_Hub_Android_Project
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be created at:
   app/build/outputs/apk/debug/app-debug.apk

APP DETAILS
Application name: ASP KUMAR School Hub
Package: com.aspkumar.schoolhub
Minimum Android: Android 6.0 (API 23)
MDM login/admin password: ASP@1994

NOTES
- Internet is required for government portal websites and online JavaScript libraries used by the MDM import/PDF features.
- MDM data uses WebView browser storage on the device. Clearing app storage can erase local MDM records.
- Government portals are opened as official websites; their login credentials are not stored by this app.
- This is source project material, not a compiled/installable APK. Build it in Android Studio to generate the APK.
